import { Component, OnInit } from '@angular/core';

import { FormBuilder,FormControl, FormGroup, FormArray } from '@angular/forms';


@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.css']
})
export class DynamicFormComponent implements OnInit {

  orderForm: FormGroup;
  items: FormArray;

  Type: any = ['Type1', 'Type2', 'Type3', 'Type4']

  SubType: any =  ['Type1.1', 'Type2.1', 'Type1.2', 'Type4.1']
  
  skills= ['value1','value2','value3','value4','value5'];

  
  selectedval

  constructor(private formBuilder: FormBuilder) {}
  
  ngOnInit() {
    this.selectedval=-1

    this.orderForm = this.formBuilder.group({      

      items: this.formBuilder.array([ 
        this.formBuilder.group({
        name: '',
        description: '',
        price: '',

        skills:this.formBuilder.array(this.skills.map(x => !1)),
        
        typeName: [''],
        subTypeName: ['']

      }) ])

    });
  }

  // {{name,description,price},{name,description,price},{name,description,price}}
  // error :  [{name,description,price},{name,description,price},{name,description,price}]

  createItem(): FormGroup {

    return this.formBuilder.group({
      name: '',
      description: '',
      price: '',
      skills:this.formBuilder.array(this.skills.map(x => !1)),
      typeName: [''],
      subTypeName: ['']
    });
  }
  addItem(): void {
    this.items = this.orderForm.get('items') as FormArray;
    this.items.push(this.createItem());
  }
  
  getData(){

     

      //this.isSubmitted = true;
      if (!this.orderForm.valid) {
        return false;
      } else {
     
        //console.log(this.orderForm.controls.items.value);
        console.log(JSON.stringify(this.orderForm.controls.items.value));
  
      }
  }

  changeType(e) {

    console.log(e.target.value);

    console.log(e.target.value.split(':')[0]);
    this.selectedval =e.target.value.split(':')[0];
    //this.SubType.splice(0,c);
    /*this.typeName.setValue(e.target.value, {
      onlySelf: true
    })*/
  }

  getSubType(){

    if(this.selectedval>-1){

      
      var selection = this.SubType;
      selection.splice(this.selectedval,1);
      
      return selection;

    }
    else{

      return ['']
    }
    
  }
}
