import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators, FormArray } from '@angular/forms';


@Component({
  selector: 'app-mcomponent',
  templateUrl: './mcomponent.component.html',
  styleUrls: ['./mcomponent.component.css']
})
export class McomponentComponent implements OnInit {

  userForm:FormGroup
  rows: FormArray  
  
  constructor(private frmBuilder:FormBuilder) {
    //this.rows = []
   }

  ngOnInit() {

    this.userForm =this.frmBuilder.group({
      rows: this.frmBuilder.array([this.createItem()])
    });

    //this.rows.push(this.userForm);
    //console.log(this.rows);

  }

  addUser(){

  
      //this.mydata.push(this.userForm.value);
      console.log(this.rows);


      /*
      fetch("http://localhost:3010/saveuser?name="+name+"&email="+email+"&pwd="+pwd)
      .then(res=>res.json())
      .then(out=>console.log(out))
*/


  }

  createItem(){

    return this.frmBuilder.group({
      
                name: ['',Validators.required],
                email: ['',Validators.required],
                pwd: ['',Validators.required],
                gender: ['',Validators.required],
                hobbies: ['',Validators.required],
                country:['',Validators.required],
                profilepic:['',Validators.required]
              });

  }
  addRow(){

    //this.rows.push(this.userForm);

    this.rows = this.userForm.get('rows') as FormArray;
    this.rows.push(this.createItem());


    for(let i=0;i<this.rows.length;i++){
        console.log(this.rows[i].value);
        console.log(this.rows[i].value.name,this.rows[i].value.pwd);

    }



  }
  delRow(i){

  //    this.rows.splice(i,1);
  }

  
}
