import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ProductComponent } from './product/product.component';
import { SortingPipe } from './sorting.pipe';
import { TaxPipe } from './tax.pipe';
import { EmployeeComponent } from './employee/employee.component';
import { EmpshowComponent } from './empshow/empshow.component';


import {ReactiveFormsModule,FormsModule} from '@angular/forms';
import { McomponentComponent } from './mcomponent/mcomponent.component';
import { CustomformDirective } from './customform.directive';
import { DynamicFormComponent } from './dynamic-form/dynamic-form.component';
import { CascadingDropdownComponent } from './cascading-dropdown/cascading-dropdown.component';

@NgModule({
  declarations: [
    CustomformDirective,
    AppComponent,
    HeaderComponent,
    FooterComponent,
    ProductComponent,
    SortingPipe,
    TaxPipe,
    EmployeeComponent,
    EmpshowComponent,
    McomponentComponent,
    DynamicFormComponent,
    CascadingDropdownComponent
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
