import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder,FormArray} from '@angular/forms';

@Component({
  selector: 'app-sales-order',
  templateUrl: './sales-order.component.html',
  styleUrls: ['./sales-order.component.css']
})
export class SalesOrderComponent implements OnInit {

  orderForm: FormGroup
  countryItems = ['India','US','UK','Aus']

  items
  constructor(private frmBuilder:FormBuilder) {
    this.items=['']
   }

  ngOnInit() {

    this.orderForm = this.frmBuilder.group({

            customerName:'',
            productName:'',
            quantity:'',
            price:'',
            country:['']
    })
  }

  
  addData(){

      console.log(this.orderForm.value); 
  }

    addMore(){
    this.items.push('')

  }
}


