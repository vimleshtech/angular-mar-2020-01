import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  items=[]
 id 
 name 
  constructor() { 

    this.items =[{id:1,name:'dove'},
                  {id:2,name:'hp laptop'},
                  {id:3,name:'iphone'}]

  }

  ngOnInit() {
  }

  setId(event){
      this.id  = event.target.value;
  }
  setName(event){
    this.name  = event.target.value;

  }
  addProduct(){
    this.items.push({id:this.id,name:this.name});
    
  }
}
