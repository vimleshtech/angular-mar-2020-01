import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'my'
})
export class MyPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    return null;
  }

  tax(amt:number): number{

    var tax =0
    if(amt<250000){
      tax = 0;
    }else if(amt<500000){

      tax = amt-250000*.05;

    }else if(amt<1000000){

      tax = amt-500000*.20;

    }else{
      tax = amt-1000000*.30;
    }

    return tax;
  }

}


