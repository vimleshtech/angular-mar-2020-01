import { Component, OnInit , Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  @Output()
  messageEvent =new EventEmitter();

  name 
  constructor() { }

  ngOnInit() {
  }
  setName(event){
    this.name =event.target.value;
  }
  
  dataEvent(){
    this.messageEvent.emit(this.name);
  }
}
