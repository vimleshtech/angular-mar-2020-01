
import { MyPipe } from './my.pipe';


describe('MyPipe', () => {

  var d; 

  it('create an instance', () => {

    const pipe = new MyPipe();

    expect(pipe).toBeTruthy();

  });


  it('create an instance2', () => {
    
       //var  pipe :MyPipe

        expect(d).toBeTruthy();
    
        
    });

    beforeAll(()=>{

      d = new MyPipe();

    });

    afterAll(()=>{

    });
      
    beforeEach(()=>{
      
    });

    afterEach(()=>{
            
      d = null;

    });
      
          
});
