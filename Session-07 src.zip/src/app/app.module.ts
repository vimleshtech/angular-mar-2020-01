import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ProductComponent } from './product/product.component';
import { SortingPipe } from './sorting.pipe';
import { TaxPipe } from './tax.pipe';
import { EmployeeComponent } from './employee/employee.component';
import { EmpshowComponent } from './empshow/empshow.component';

import {ReactiveFormsModule} from '@angular/forms';
import { McomponentComponent } from './mcomponent/mcomponent.component';
import { CustomformDirective } from './customform.directive';

@NgModule({
  declarations: [
    CustomformDirective,
    AppComponent,
    HeaderComponent,
    FooterComponent,
    ProductComponent,
    SortingPipe,
    TaxPipe,
    EmployeeComponent,
    EmpshowComponent,
    McomponentComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
