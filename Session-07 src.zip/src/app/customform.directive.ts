import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appCustomform]'
})
export class CustomformDirective {

  constructor(el : ElementRef) { 

    el.nativeElement.style.color="red";
    el.nativeElement.innerHTML="<input type='text' /> ";


  }

}
