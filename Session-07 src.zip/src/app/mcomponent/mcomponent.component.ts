import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';

@Component({
  selector: 'app-mcomponent',
  templateUrl: './mcomponent.component.html',
  styleUrls: ['./mcomponent.component.css']
})
export class McomponentComponent implements OnInit {


  userForm:FormGroup
  rows 
  mydata
  
  constructor(private frmBuilder:FormBuilder) {

    this.rows = []
    this.mydata =[]

   }

  ngOnInit() {

    this.userForm =this.frmBuilder.group({

        name: ['',Validators.required],
        email: ['',Validators.required],
        pwd: ['',Validators.required],
        gender: ['',Validators.required],
        hobbies: ['',Validators.required],
        country:['',Validators.required],
        profilepic:['',Validators.required]
    });

    this.rows.push(this.userForm);


  }

  addUser(){

      console.log(this.userForm.value)
      //console.log(this.userForm.value.name)
      //console.log(this.userForm.value.email)
      //console.log(this.userForm.value.pwd)
      var name =  this.userForm.value.name;
      var email= this.userForm.value.email;
      var pwd = this.userForm.value.pwd;

      //this.mydata.push(this.userForm.value);
      console.log(this.rows);


      

      /*
      fetch("http://localhost:3010/saveuser?name="+name+"&email="+email+"&pwd="+pwd)
      .then(res=>res.json())
      .then(out=>console.log(out))
*/


  }

  addRow(){

    this.userForm =this.frmBuilder.group({
      
              name: ['',Validators.required],
              email: ['',Validators.required],
              pwd: ['',Validators.required],
              gender: ['',Validators.required],
              hobbies: ['',Validators.required],
              country:['',Validators.required],
              profilepic:['',Validators.required]
          });

          
    this.rows.push(this.userForm);

    //this.rows.push("");
    


  }
  delRow(i){

      this.rows.splice(i,1);
  }

}
