import { CustomformDirective } from './customform.directive';

describe('CustomformDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomformDirective();
    expect(directive).toBeTruthy();
  });
});
