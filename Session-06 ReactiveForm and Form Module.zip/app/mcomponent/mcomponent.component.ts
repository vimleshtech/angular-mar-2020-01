import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';

@Component({
  selector: 'app-mcomponent',
  templateUrl: './mcomponent.component.html',
  styleUrls: ['./mcomponent.component.css']
})
export class McomponentComponent implements OnInit {


  userForm:FormGroup

  constructor(private frmBuilder:FormBuilder) { }

  ngOnInit() {

    this.userForm =this.frmBuilder.group({

        name: ['',Validators.required],
        email: ['',Validators.required],
        pwd: ['',Validators.required],        
    });
  }

  addUser(){

      //console.log(this.userForm.value)
      //console.log(this.userForm.value.name)
      //console.log(this.userForm.value.email)
      //console.log(this.userForm.value.pwd)
      var name =  this.userForm.value.name;
      var email= this.userForm.value.email;
      var pwd = this.userForm.value.pwd;

      fetch("http://localhost:3010/saveuser?name="+name+"&email="+email+"&pwd="+pwd)
      .then(res=>res.json())
      .then(out=>console.log(out))


  }

}
