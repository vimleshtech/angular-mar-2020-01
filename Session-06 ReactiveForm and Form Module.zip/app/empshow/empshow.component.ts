import { Component, OnInit,OnChanges, SimpleChanges, Input } from '@angular/core';

//SimpleChanges : oldvalue
//SimpleChanges: currentvalue
//SimpleChanges: firstvalue
//SimpleChanges: isfirstchange 

@Component({
  selector: 'app-empshow',
  templateUrl: './empshow.component.html',
  styleUrls: ['./empshow.component.css']
})
export class EmpshowComponent implements OnInit ,OnChanges{

  //receive data from parent 
  @Input()
  empdata

  constructor() { 
      
  }

  ngOnInit() {
  }


  ngOnChanges(changes: SimpleChanges) {
    console.log(changes+'in onchanges.. ');
    console.log(changes.currentvalue);
    console.log(changes.oldvalue);

   alert('hi');
    
  }

}
