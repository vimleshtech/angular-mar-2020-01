import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  name:string
  price:number
  quantity:number 
  data
  eind 
 // mdata 
  totalcount
  markcount
  unmarkcount

  dob

  arrdata  = ["rahul", "nitin", "jatin", "aman"]

  constructor() {

    this.data  = []
   // this.mdata=[]
    this.totalcount=0
    this.markcount=0
    this.unmarkcount = 0
    this.frm_clear();

    this.dob =new Date(1988,10,1);
   }

  ngOnInit() {
  }

 setName(event){
      this.name = event.target.value;
 }
 setPrice(event){
  this.price = event.target.value;
 }
 setQuantity(event){
  this.quantity = event.target.value;
 }
  btn_submit(){

        this.data.push({pname:this.name,price:this.price,qty:this.quantity,ismark:false});
        console.log(this.data);
        this.frm_summary();

        this.frm_clear();
        
  }



  btn_del(ind){

      this.data.splice(ind,1);
      //this.mdata.splice(ind,1);
      this.frm_summary();


  }

  btn_edit(i){

      this.name =   this.data[i].pname;
      this.price =  this.data[i].price;
      this.quantity =  this.data[i].qty;
      this.eind = i 
  }
  btn_update(){

    if(this.eind>-1){
     this.data[ this.eind].pname =this.name;
     this.data[ this.eind].price =this.price;
     this.data[ this.eind].qty =this.quantity;
    this.frm_clear();
    }
  }
  frm_mark(i){
      //this.mdata.push(i);
      this.data[i].ismark = !this.data[i].ismark;
      this.frm_summary();
  }
  frm_clear(){
    this.name="";
    this.price=0;
    this.quantity=0;
    this.eind =-1;

  }
  frm_summary(){

    this.totalcount=this.data.length;
    this.markcount= this.data.filter(x=> x.ismark== true).length;   
    this.unmarkcount = this.totalcount- this.markcount;

  }
  frm_delAll(){
    this.data = this.data.filter(x=> x.ismark == false);
    this.frm_summary();
  }
}
