import { Component,SimpleChanges, OnChanges 
  , OnInit,DoCheck,AfterContentInit , AfterContentChecked,AfterViewInit,AfterViewChecked,OnDestroy  
} from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements 
OnInit,DoCheck ,AfterContentInit , AfterContentChecked ,AfterViewInit,AfterViewChecked,OnDestroy
{

  name
  email
  emplist 
  constructor() {
    this.emplist = []

    console.log('in constructor- Employee component');

   }


  ngOnInit() {
    console.log('in ngOnInit - Employee component');
  }

  

  ngAfterContentInit() {

    console.log('in angular aftercontent init - ');

    }


ngDoCheck (){

  console.log('in angular docheck- Employee component');

}
ngAfterContentChecked(){
  console.log('after content checked - in  Employee Component')
}
ngAfterViewInit(){

  console.log('in ngafterview init - in employee compoenent');

}

ngAfterViewChecked(){
  console.log('in ngafterview checked - Employee component');

}

ngOnDestroy(){
  console.log('in ngonDestory - Employee component');
}
  setName(event){
      this.name = event.target.value;
  }
  setEmail(event){
    this.email = event.target.value;

  }

  frm_add(){

      this.emplist.push({name:this.name, email:this.email});
      console.log(this.emplist);
  }
}
