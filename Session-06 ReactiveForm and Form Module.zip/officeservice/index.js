
const expess = require('express');
const mysql = require('mysql');


const  app = expess();

var con =  mysql.createConnection({

    host    : 'localhost',
    user    : 'root',
    password: 'root',
    database: 'officetool'    
})

app.get('',(req,res)=>{


    res.json({code:200,msg:'test message'})
})
app.get('/users',(req,res)=>{
    
    
        res.json({code:200,msg:'in users'})
    })

    app.get('/saveuser',(req,res)=>{

        
         // Website you wish to allow to connect
        res.setHeader('Access-Control-Allow-Origin', '*');
    
        // Request methods you wish to allow
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    
        // Request headers you wish to allow
        //res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    
        // Set to true if you need the website to include cookies in the requests sent
        // to the API (e.g. in case you use sessions)
        //res.setHeader('Access-Control-Allow-Credentials', true);

            var name =  req.query.name;
            var email = req.query.email;
            var pwd= req.query.pwd;

            console.log(' name  ',name,email,pwd);
            con.connect(function(err) {

                if (err) 
                    throw err;

                console.log("Connected!");
                //"+name+"
                var sql = "INSERT INTO users(name,email,pwd) values('"+name+"','"+email+"','"+pwd+"')";

                con.query(sql, function (err, result) {
                
                    if (err) throw err;

                  console.log("1 record inserted ",result);

                });
              });

              
            
            res.json({code:200,msg:'in saveuser'})
        })

        
app.listen(3010,()=>{

    console.log('server is running at 3010');
})

